#!/usr/bin/env python3
import numpy as np
hartree2eV=13.605826
au2angstrom=0.529177249
au2debye=2.541746
#c=0.26246582250210965422
c=1/hartree2eV/au2angstrom/au2angstrom
au2fs=0.02418884326505
